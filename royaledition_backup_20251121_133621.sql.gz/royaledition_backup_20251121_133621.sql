-- MySQL dump 10.13  Distrib 9.5.0, for macos14.8 (arm64)
--
-- Host: localhost    Database: royaledition
-- ------------------------------------------------------
-- Server version	9.5.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '864604d4-c6b5-11f0-a68a-58a73d3d7cb4:1-32';

--
-- Table structure for table `BlogPost`
--

DROP TABLE IF EXISTS `BlogPost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BlogPost` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8mb4_unicode_ci,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `coverImage` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Royal Editions',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `metaTitle` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaDescription` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `BlogPost_slug_key` (`slug`),
  KEY `BlogPost_slug_idx` (`slug`),
  KEY `BlogPost_published_idx` (`published`),
  KEY `BlogPost_createdAt_idx` (`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BlogPost`
--

LOCK TABLES `BlogPost` WRITE;
/*!40000 ALTER TABLE `BlogPost` DISABLE KEYS */;
INSERT INTO `BlogPost` VALUES ('cmi8m2h5u0008ggtgvgk5ygh7','Bienvenue sur Royal Editions','bienvenue-royal-editions','Découvrez notre nouvelle librairie en ligne premium dédiée aux livres d\'exception.','<h2>Une nouvelle ère pour la lecture en Côte d\'Ivoire</h2>\n        <p>Royal Editions est fière de vous présenter sa plateforme e-commerce dédiée aux livres de qualité premium.</p>\n        <h3>Notre mission</h3>\n        <p>Rendre accessible à tous les Ivoiriens des livres d\'exception qui transforment les vies et enrichissent les connaissances.</p>\n        <h3>Nos engagements</h3>\n        <ul>\n          <li>Sélection rigoureuse de livres de qualité</li>\n          <li>Livraison rapide dans toute la Côte d\'Ivoire</li>\n          <li>Paiement sécurisé à la livraison</li>\n          <li>Service client réactif</li>\n        </ul>\n        <p>Rejoignez notre communauté de lecteurs passionnés!</p>','/assets/Logo-Royal-Editions.png','Royal Editions',1,'Bienvenue sur Royal Editions - Votre librairie premium','Découvrez Royal Editions, votre nouvelle librairie en ligne en Côte d\'Ivoire','2025-11-21 08:41:28.675','2025-11-21 08:41:28.675');
/*!40000 ALTER TABLE `BlogPost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Book`
--

DROP TABLE IF EXISTS `Book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Book` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `summary` text COLLATE utf8mb4_unicode_ci,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `originalPrice` decimal(10,2) DEFAULT NULL,
  `stock` int NOT NULL DEFAULT '0',
  `images` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `categoryId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `bestseller` tinyint(1) NOT NULL DEFAULT '0',
  `metaTitle` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaDescription` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Book_slug_key` (`slug`),
  KEY `Book_slug_idx` (`slug`),
  KEY `Book_categoryId_idx` (`categoryId`),
  KEY `Book_featured_idx` (`featured`),
  KEY `Book_bestseller_idx` (`bestseller`),
  CONSTRAINT `Book_categoryId_fkey` FOREIGN KEY (`categoryId`) REFERENCES `Category` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Book`
--

LOCK TABLES `Book` WRITE;
/*!40000 ALTER TABLE `Book` DISABLE KEYS */;
INSERT INTO `Book` VALUES ('cmi8m2h5n0004ggtggspnm62b','Maîtrisez l’anglais des affaires pour booster votre carrière','maitrisez-l-anglais-des-affaires-pour-booster-votre-carriere','Royal Editions','Le guide complet pour communiquer efficacement en milieu professionnel international','<p>Vous souhaitez progresser en anglais professionnel, gagner en aisance, rédiger des e-mails impeccables, mener des réunions en anglais et communiquer avec impact dans un environnement international ? Ce guide pratique est l’outil essentiel pour maîtriser l’anglais des affaires et booster votre carrière. Grâce à des exemples concrets, un vocabulaire ciblé et des situations réelles, vous apprendrez à communiquer avec fluidité, confiance et professionnalisme.</p><p></p><p>L’anglais des affaires n’est plus une compétence optionnelle : c’est un levier indispensable pour évoluer dans le monde professionnel moderne. Réunions internationales, présentations, e-mails professionnels, négociations, entretiens, collaborations à distance… Tout exige aujourd’hui une maîtrise solide et confiante de l’anglais. Mais comment apprendre rapidement, efficacement et surtout de façon pratique ?</p><p><strong>« Maîtrisez l’anglais des affaires pour booster votre carrière »</strong> a été conçu comme un coach linguistique personnel, simple à utiliser, accessible à tous et 100 % orienté vers l’action. Que vous soyez étudiant, employé, entrepreneur ou cadre, vous y trouverez les outils adaptés pour communiquer avec assurance dans le monde professionnel anglophone.</p><p>Ce guide vous plonge au cœur de situations réelles : conversations téléphoniques, réunions stratégiques, présentations orales, échanges avec des collègues étrangers, négociations délicates… Grâce à des dialogues authentiques, des exemples de courriels, des structures de phrases prêtes à l’emploi et un vocabulaire ciblé, vous développez immédiatement vos compétences.</p><p>Vous apprendrez à :</p><ul><li><p>Maîtriser l’anglais professionnel dans tous vos échanges ;</p></li><li><p>Rédiger des e-mails et rapports clairs et professionnels ;</p></li><li><p>Utiliser les expressions clés des réunions et présentations ;</p></li><li><p>Renforcer votre impact dans les négociations ;</p></li><li><p>Adapter votre ton selon votre interlocuteur ou le contexte ;</p></li><li><p>Progresser à l’oral comme à l’écrit grâce à des exercices pratiques.</p></li></ul><p>Ce livre se distingue aussi par son approche motivante et accessible : il vous accompagne pas à pas, sans jargon inutile, et vous permet de progresser avec fluidité quel que soit votre niveau actuel. Plus qu’un simple manuel, c’est un accélérateur de carrière, pensé pour renforcer votre confiance et développer vos compétences professionnelles.</p><p>Grâce à son format compact, vous pouvez le consulter au bureau, en déplacement, à la maison ou même dans les transports. Vous avancerez chaque jour, à votre rythme, en intégrant progressivement les éléments essentiels de l’anglais des affaires.</p><p>Si vous recherchez une ressource claire, efficace, moderne et hautement pratique pour réussir dans le monde professionnel international, ce guide deviendra rapidement votre meilleur allié.</p><p></p><p><strong>Pourquoi vous allez l’adorer</strong></p><ul><li><p>✔ Des mises en situations réelles du monde professionnel pour apprendre rapidement et efficacement.</p></li><li><p>✔ Des exemples concrets (e-mails, conversations, négociations, présentations) pour une application immédiate.</p></li><li><p>✔ Un vocabulaire ciblé, actuel et utilisé dans les entreprises internationales.</p></li><li><p>✔ Un format pratique, facile à transporter et à consulter partout.</p></li></ul><p>✔ Une approche motivante qui renforce la confiance et l’aisance, même pour les débutants.</p><p></p><p><strong>À qui s’adresse ce livre ?</strong></p><ul><li><p>• Aux managers, cadres et employés qui veulent évoluer ou performer dans un environnement international.</p></li><li><p>• Aux entrepreneurs souhaitant communiquer efficacement avec des partenaires étrangers.</p></li><li><p>• Aux agents du secteur public ou international.</p></li><li><p>• Aux étudiants, chercheurs d’emploi et jeunes diplômés.</p></li><li><p>• Aux formateurs, enseignants et professionnels de la communication.</p></li><li><p>• À toute personne désirant améliorer son anglais professionnel pour booster sa carrière.</p></li></ul><p></p><p><strong>Ce qui rend ce guide unique</strong></p><p>Contrairement aux manuels classiques souvent trop théoriques, ce guide offre :</p><ul><li><p>Des situations professionnelles authentiques ;</p></li><li><p>Des exemples directement utilisables ;</p></li><li><p>Un vocabulaire réellement employé en entreprise ;</p></li><li><p>Un vocabulaire spécifique pour chaque métier du monde professionnel&nbsp;;</p></li><li><p>Une approche progressive et motivante ;</p></li><li><p>Un format accessible, clair et pensé pour la pratique quotidienne.</p></li></ul><p>Il ne vous apprend pas seulement l’anglais : il vous apprend à réussir en anglais.</p><p></p><p><strong>Passez à l’action dès aujourd’hui !</strong></p><p>Votre carrière mérite d’aller plus loin. Avec ce guide, vous aurez enfin les outils pour communiquer avec assurance, impressionner vos interlocuteurs et saisir les meilleures opportunités professionnelles.<br>✨ <strong>Commandez votre exemplaire maintenant</strong> et commencez votre transformation linguistique et professionnelle.</p><p>📦 Format : A5 – 263 pages</p><p>🏷️ Éditeur : Royal Éditions</p><p>🌍 Langue : Anglais/français</p><p></p>',10000.00,15000.00,20,'[\"https://royale-edition-content.s3.eu-north-1.amazonaws.com/books/maitrisez-l-anglais-des-affaires-pour-booster-votr-1763722460745-xo5ha1.png\"]','cmi8m2h5k0002ggtgap9bkmgh',0,0,'1000 Techniques Professionnelles - Guide Complet','Maîtrisez 1000 techniques essentielles pour exceller dans votre carrière professionnelle.','2025-11-21 08:41:28.667','2025-11-21 10:56:21.054'),('cmi8o8msl0001gg7zcdqfiyu9','1000 techniques pour convaincre et influencer avec impact','1000-techniques-pour-convaincre-et-influencer-avec-impact','Royal Editions','Le guide pratique pour s’exprimer avec charisme, captiver votre public et convaincre dans toutes les situations','<p>Vous souhaitez maîtriser la prise de parole en public, développer votre charisme, convaincre avec assurance et laisser une impression durable ? Ce livre vous dévoile des techniques simples, pratiques et immédiatement applicables pour vous transformer en un communicant confiant, impactant et charismatique. Que vous soyez débutant ou déjà à l’aise à l’oral, vous découvrirez comment parler en public avec aisance, captiver votre auditoire et influencer positivement dans toutes vos interactions.</p><p>Parler en public, convaincre et influencer ne sont pas des talents innés réservés à une poignée de privilégiés : ce sont des compétences qui s\'apprennent, se développent et se maîtrisent. Dans un monde où l’expression orale est devenue un atout majeur pour réussir, savoir comment prendre la parole en public, structurer un message clair et transmettre une émotion authentique est indispensable, que ce soit dans votre vie personnelle, professionnelle ou entrepreneuriale.</p><p>« 1000 techniques pour convaincre et influencer avec impact » est un véritable coach de poche, conçu pour vous accompagner pas à pas dans votre progression. En plus d’être un livre de développement personnel puissant, il est aussi un manuel pratique rempli de stratégies concrètes, d’exemples réels et d’astuces applicables immédiatement pour améliorer vos prises de parole.</p><p></p><img class=\"rounded-lg max-w-full h-auto\" src=\"https://royale-edition-content.s3.eu-north-1.amazonaws.com/editor-images/1000-techniques-pour-convaincre-et-influencer-1763719638021-cn15mh.png\"><p></p><h2><strong>À l’intérieur, vous découvrirez :</strong></h2><ul><li><p>✔ Comment développer un charisme naturel ;</p></li><li><p>✔ Comment renforcer votre présence, votre voix et votre langage corporel ;</p></li><li><p>✔ Comment captiver un public dès les premières secondes ;</p></li><li><p>✔ Comment structurer un message percutant et mémorable ;</p></li><li><p>✔ Comment parler en public même sous pression, sans stress ni hésitation ;</p></li><li><p>✔ Comment influencer positivement et convaincre avec empathie et crédibilité.</p></li></ul><p>Ce guide ne se contente pas d’expliquer : il vous entraîne, vous motive et vous pousse à révéler une version plus confiante, affirmée et charismatique de vous-même.</p><p>Grâce à ses chapitres courts, pédagogiques et profonds, ce livre vous aidera à surmonter vos peurs, à renforcer votre mental, à améliorer votre communication et à développer votre pouvoir d’influence dans toutes les situations : réunions, entretiens d’embauche, interventions professionnelles, pitchs, présentations, conversations informelles, et même dans votre vie quotidienne.</p><p>Si vous recherchez un livre de développement personnel pratique, inspirant et orienté résultats, ce guide est la ressource idéale pour booster votre croissance personnelle, votre confiance et votre impact.</p><h2><strong>Pourquoi vous allez l’adorer</strong></h2><ul><li><p>✔ 1000 techniques concrètes, simples et immédiatement applicables pour devenir plus charismatique.</p></li><li><p>✔ Une méthode progressive pour apprendre comment parler en public sans stress ni hésitations.</p></li><li><p>✔ Des stratégies puissantes pour captiver n’importe quel public, même le plus difficile.</p></li><li><p>✔ Un guide motivant orienté résultats, des modèles et des expressions prêtes à l’emploi.</p></li><li><p>✔ Une transformation personnelle réelle : plus de confiance, plus d’assurance, plus d’impact.</p></li></ul><p></p><p></p><h2><strong>À qui s’adresse ce livre ?</strong></h2><ul><li><p>• Aux personnes qui souhaitent améliorer leur prise de parole en public.</p></li><li><p>• Aux leaders, managers et entrepreneurs qui veulent devenir plus convaincants.</p></li><li><p>• Aux étudiants et candidats aux concours souhaitant booster leur aisance orale.</p></li><li><p>• Aux enseignants, formateurs, coachs et communicateurs.</p></li><li><p>• Aux personnes souhaitant renforcer leur charisme et leur influence naturelle.</p></li><li><p>• À toute personne engagée dans un parcours de développement personnel et de réussite.</p></li></ul><p></p><img class=\"rounded-lg max-w-full h-auto\" src=\"https://royale-edition-content.s3.eu-north-1.amazonaws.com/editor-images/livre-1000-techniques-pour-convaincre-et-influence-1763719431364-9kjmrm.png\"><p></p><h2><strong>Ce qui rend ce livre unique</strong></h2><p>Contrairement aux ouvrages théoriques souvent trop abstraits, ce guide est 100 % pratique, accessible et orienté action.<br>Il combine développement personnel, techniques de communication, psychologie de l’influence et stratégies d’expression orale dans un format clair et motivant.<br>Chaque page a été conçue pour vous faire progresser rapidement, avec des outils concrets que vous pouvez appliquer dès la première lecture.<br>Un livre pensé pour la transformation, pas seulement pour la lecture.</p><h2><strong>Passez à l’action maintenant !</strong></h2><p>Vous avez le potentiel d’être convaincant, inspirant et charismatique. Il vous suffit d’un guide pour libérer cette puissance.<br>✨ <strong>Commandez votre exemplaire dès maintenant</strong> et commencez votre transformation.<br>Votre voix, vos idées et votre impact méritent d’être entendus.</p><p>📦 Format : A5 – 177 pages</p><p>🏷️ Éditeur : Royal Éditions</p><p>🌍 Langue : Français</p>',10000.00,10000.00,100,'[\"https://royale-edition-content.s3.eu-north-1.amazonaws.com/books/1000-techniques-pour-convaincre-et-influencer-avec-1763718120580-839acd.png\"]','cmi8m2h5j0001ggtgfzpxj6tl',1,1,'','','2025-11-21 09:42:15.133','2025-11-21 10:07:43.696');
/*!40000 ALTER TABLE `Book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Category`
--

DROP TABLE IF EXISTS `Category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Category` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaTitle` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaDescription` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Category_slug_key` (`slug`),
  KEY `Category_slug_idx` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Category`
--

LOCK TABLES `Category` WRITE;
/*!40000 ALTER TABLE `Category` DISABLE KEYS */;
INSERT INTO `Category` VALUES ('cmi8m2h5h0000ggtg1hzulwyl','Business & Entrepreneuriat','business-entrepreneuriat','Guides et stratégies pour entrepreneurs et leaders',NULL,'Business & Entrepreneuriat | Royal Editions','Livres sur le business et l\'entrepreneuriat','2025-11-21 08:41:28.662','2025-11-21 08:41:28.662'),('cmi8m2h5j0001ggtgfzpxj6tl','Développement Personnel','developpement-personnel','Livres pour améliorer votre vie personnelle et professionnelle',NULL,'Développement Personnel | Royal Editions','Découvrez nos livres de développement personnel','2025-11-21 08:41:28.662','2025-11-21 08:41:28.662'),('cmi8m2h5k0002ggtgap9bkmgh','Techniques & Savoir-faire','techniques-savoir-faire','Guides pratiques et techniques professionnelles',NULL,'Techniques & Savoir-faire | Royal Editions','Guides techniques et pratiques','2025-11-21 08:41:28.662','2025-11-21 08:41:28.662');
/*!40000 ALTER TABLE `Category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ChatConversation`
--

DROP TABLE IF EXISTS `ChatConversation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ChatConversation` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visitorId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visitorName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `visitorEmail` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `lastMessageAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ChatConversation_visitorId_key` (`visitorId`),
  KEY `ChatConversation_status_idx` (`status`),
  KEY `ChatConversation_lastMessageAt_idx` (`lastMessageAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ChatConversation`
--

LOCK TABLES `ChatConversation` WRITE;
/*!40000 ALTER TABLE `ChatConversation` DISABLE KEYS */;
/*!40000 ALTER TABLE `ChatConversation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ChatMessage`
--

DROP TABLE IF EXISTS `ChatMessage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ChatMessage` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversationId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `senderName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Visiteur',
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `ChatMessage_conversationId_idx` (`conversationId`),
  KEY `ChatMessage_createdAt_idx` (`createdAt`),
  CONSTRAINT `ChatMessage_conversationId_fkey` FOREIGN KEY (`conversationId`) REFERENCES `ChatConversation` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ChatMessage`
--

LOCK TABLES `ChatMessage` WRITE;
/*!40000 ALTER TABLE `ChatMessage` DISABLE KEYS */;
/*!40000 ALTER TABLE `ChatMessage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LegalPage`
--

DROP TABLE IF EXISTS `LegalPage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LegalPage` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `LegalPage_slug_key` (`slug`),
  KEY `LegalPage_slug_idx` (`slug`),
  KEY `LegalPage_published_idx` (`published`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LegalPage`
--

LOCK TABLES `LegalPage` WRITE;
/*!40000 ALTER TABLE `LegalPage` DISABLE KEYS */;
INSERT INTO `LegalPage` VALUES ('cmi8sx5u70000ggyw53mzvr3e','cgv','Conditions Générales de Vente','<h2>1. Objet</h2>\n<p>Les présentes Conditions Générales de Vente (CGV) régissent les ventes de livres effectuées par Royal Editions sur son site internet.</p>\n\n<h2>2. Prix</h2>\n<p>Les prix sont indiqués en Francs CFA (FCFA) et sont valables au moment de la commande. Royal Editions se réserve le droit de modifier ses prix à tout moment, mais les produits seront facturés sur la base des tarifs en vigueur au moment de la validation de la commande.</p>\n\n<h2>3. Commande</h2>\n<p>Toute commande passée sur le site implique l\'acceptation des présentes CGV. Le client reconnaît avoir pris connaissance et accepté les présentes conditions générales de vente avant de passer commande.</p>\n<p>La vente ne sera considérée comme définitive qu\'après l\'envoi au client de la confirmation de l\'acceptation de la commande par Royal Editions.</p>\n\n<h2>4. Paiement</h2>\n<p>Le paiement s\'effectue à la livraison, en espèces uniquement. Aucun paiement en ligne n\'est requis lors de la commande.</p>\n<p>Le montant total dû sera remis au livreur lors de la réception de votre commande.</p>\n\n<h2>5. Livraison</h2>\n<p>Les livraisons sont effectuées à l\'adresse indiquée par le client lors de la commande.</p>\n<p>Les délais de livraison sont donnés à titre indicatif et peuvent varier en fonction de la disponibilité des produits et de la zone de livraison.</p>\n<p>Notre service de livraison vous contactera pour confirmer l\'adresse et convenir d\'un horaire de livraison.</p>\n\n<h2>6. Droit de rétractation</h2>\n<p>Conformément à la législation en vigueur, le client dispose d\'un délai de 7 jours à compter de la réception de sa commande pour exercer son droit de rétractation.</p>\n<p>Pour exercer ce droit, le client doit nous contacter par téléphone ou email et renvoyer le(s) produit(s) dans leur emballage d\'origine, en parfait état.</p>\n\n<h2>7. Garantie</h2>\n<p>Tous nos livres sont neufs et en parfait état. En cas de défaut ou de dommage lors de la livraison, veuillez nous contacter immédiatement.</p>\n<p>Un remplacement sera effectué dans les meilleurs délais.</p>\n\n<h2>8. Responsabilité</h2>\n<p>Royal Editions ne saurait être tenu responsable de l\'inexécution du contrat en cas de rupture de stock, d\'indisponibilité du produit, de force majeure, de perturbation ou grève totale ou partielle des services postaux ou de moyens de transport et/ou communications.</p>\n\n<h2>9. Protection des données personnelles</h2>\n<p>Les informations recueillies font l\'objet d\'un traitement informatique destiné à la gestion des commandes. Conformément à la loi, vous disposez d\'un droit d\'accès, de modification et de suppression des données vous concernant.</p>\n\n<h2>10. Litiges</h2>\n<p>Les présentes CGV sont soumises au droit ivoirien. En cas de litige, une solution amiable sera recherchée avant toute action judiciaire.</p>\n\n<h2>11. Contact</h2>\n<p>Pour toute question concernant nos conditions générales de vente, vous pouvez nous contacter :</p>\n<ul>\n  <li>Par téléphone : +225 00 00 00 00 00</li>\n  <li>Par email : contact@royaleditions.ci</li>\n  <li>Par courrier : Abidjan, Côte d\'Ivoire</li>\n</ul>',1,'2025-11-21 11:53:18.031','2025-11-21 11:53:18.031'),('cmi8sx5ui0001ggywwnxdaxc6','confidentialite','Politique de Confidentialité','<h2>1. Introduction</h2>\n<p>Royal Editions attache une grande importance à la protection de vos données personnelles. Cette politique de confidentialité explique comment nous collectons, utilisons et protégeons vos informations personnelles.</p>\n\n<h2>2. Données collectées</h2>\n<p>Nous collectons les informations suivantes lors de votre commande :</p>\n<ul>\n  <li>Nom complet</li>\n  <li>Numéro de téléphone</li>\n  <li>Adresse email (optionnel)</li>\n  <li>Adresse de livraison complète</li>\n</ul>\n\n<h2>3. Utilisation des données</h2>\n<p>Vos données personnelles sont utilisées uniquement pour :</p>\n<ul>\n  <li>Traiter et livrer votre commande</li>\n  <li>Vous contacter concernant votre commande</li>\n  <li>Améliorer nos services</li>\n  <li>Vous envoyer des informations sur nos produits (avec votre consentement)</li>\n</ul>\n\n<h2>4. Partage des données</h2>\n<p>Nous ne vendons, n\'échangeons ni ne louons vos informations personnelles à des tiers.</p>\n<p>Vos données peuvent être partagées uniquement avec :</p>\n<ul>\n  <li>Notre service de livraison (uniquement les informations nécessaires à la livraison)</li>\n  <li>Les autorités compétentes si la loi l\'exige</li>\n</ul>\n\n<h2>5. Sécurité des données</h2>\n<p>Nous mettons en œuvre des mesures de sécurité appropriées pour protéger vos données personnelles contre tout accès non autorisé, modification, divulgation ou destruction.</p>\n<p>Nos systèmes sont protégés et régulièrement mis à jour pour garantir la sécurité de vos informations.</p>\n\n<h2>6. Conservation des données</h2>\n<p>Vos données personnelles sont conservées pendant la durée nécessaire à la réalisation des finalités pour lesquelles elles ont été collectées, conformément aux obligations légales de conservation.</p>\n\n<h2>7. Vos droits</h2>\n<p>Conformément à la réglementation en vigueur, vous disposez des droits suivants :</p>\n<ul>\n  <li>Droit d\'accès à vos données personnelles</li>\n  <li>Droit de rectification de vos données</li>\n  <li>Droit à l\'effacement de vos données</li>\n  <li>Droit d\'opposition au traitement de vos données</li>\n  <li>Droit à la portabilité de vos données</li>\n</ul>\n<p>Pour exercer ces droits, contactez-nous à : contact@royaleditions.ci</p>\n\n<h2>8. Cookies</h2>\n<p>Notre site utilise des cookies pour améliorer votre expérience de navigation. Les cookies nous permettent de :</p>\n<ul>\n  <li>Mémoriser votre panier d\'achat</li>\n  <li>Analyser l\'utilisation de notre site</li>\n  <li>Personnaliser votre expérience</li>\n</ul>\n<p>Vous pouvez désactiver les cookies dans les paramètres de votre navigateur, mais cela peut affecter certaines fonctionnalités du site.</p>\n\n<h2>9. Modifications</h2>\n<p>Nous nous réservons le droit de modifier cette politique de confidentialité à tout moment. Les modifications entreront en vigueur dès leur publication sur cette page.</p>\n<p>Nous vous encourageons à consulter régulièrement cette page pour rester informé de nos pratiques en matière de confidentialité.</p>\n\n<h2>10. Contact</h2>\n<p>Pour toute question concernant cette politique de confidentialité ou vos données personnelles, vous pouvez nous contacter :</p>\n<ul>\n  <li>Par email : contact@royaleditions.ci</li>\n  <li>Par téléphone : +225 00 00 00 00 00</li>\n  <li>Par courrier : Royal Editions, Abidjan, Côte d\'Ivoire</li>\n</ul>',1,'2025-11-21 11:53:18.043','2025-11-21 11:53:18.043');
/*!40000 ALTER TABLE `LegalPage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Order`
--

DROP TABLE IF EXISTS `Order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Order` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `orderNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerEmail` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customerPhone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shippingCity` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shippingArea` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shippingAddress` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `observations` text COLLATE utf8mb4_unicode_ci,
  `status` enum('PENDING','PROCESSING','DELIVERED','CANCELLED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `totalAmount` decimal(10,2) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Order_orderNumber_key` (`orderNumber`),
  KEY `Order_orderNumber_idx` (`orderNumber`),
  KEY `Order_status_idx` (`status`),
  KEY `Order_createdAt_idx` (`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Order`
--

LOCK TABLES `Order` WRITE;
/*!40000 ALTER TABLE `Order` DISABLE KEYS */;
/*!40000 ALTER TABLE `Order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrderItem`
--

DROP TABLE IF EXISTS `OrderItem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OrderItem` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `orderId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bookId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `OrderItem_orderId_idx` (`orderId`),
  KEY `OrderItem_bookId_idx` (`bookId`),
  CONSTRAINT `OrderItem_bookId_fkey` FOREIGN KEY (`bookId`) REFERENCES `Book` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `OrderItem_orderId_fkey` FOREIGN KEY (`orderId`) REFERENCES `Order` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrderItem`
--

LOCK TABLES `OrderItem` WRITE;
/*!40000 ALTER TABLE `OrderItem` DISABLE KEYS */;
/*!40000 ALTER TABLE `OrderItem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Testimonial`
--

DROP TABLE IF EXISTS `Testimonial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Testimonial` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` int NOT NULL DEFAULT '5',
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Testimonial_active_idx` (`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Testimonial`
--

LOCK TABLES `Testimonial` WRITE;
/*!40000 ALTER TABLE `Testimonial` DISABLE KEYS */;
INSERT INTO `Testimonial` VALUES ('cmi8m2h5r0005ggtgdyic3ipf','Kouadio Marie','Entrepreneure','Les livres de Royal Editions ont transformé ma vision du business. Service excellent et livraison rapide!',5,NULL,1,'2025-11-21 08:41:28.671','2025-11-21 08:41:28.671'),('cmi8m2h5r0006ggtg07co7gce','Yao Jean','Étudiant','Collection exceptionnelle de livres. Le paiement à la livraison est très pratique.',5,NULL,1,'2025-11-21 08:41:28.671','2025-11-21 08:41:28.671'),('cmi8m2h5r0007ggtgwdkdazqs','Adjoua Aya','Manager','Royal Editions est ma librairie préférée. Qualité premium et conseils personnalisés.',5,NULL,1,'2025-11-21 08:41:28.671','2025-11-21 08:41:28.671');
/*!40000 ALTER TABLE `Testimonial` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-21 13:37:05
